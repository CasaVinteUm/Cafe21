#include <Arduino.h>
#include <Wire.h>
#include <SoftwareSerial.h>

#define I2C_ADDRESS 0x0A

#define DEBUG_SFW
#define DEBUG_DISPLAY
#define PANEL_GND_PIN 7 //D7

// Define the Serial pins
#define TX_PIN 12 // Transmit pin: TX -> Coffee Machine Panel 4
#define RX_PIN 11 // Receive pin:  RX <- Coffee Machine Panel 5

// Create a serial object for communication with the panel coffee machine
SoftwareSerial PanelSerial(RX_PIN, TX_PIN);

byte byteToSend[19] = {0}; // ,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};//,0,0,0,0,0,0,0,0,0,0,0,0,0};
                   // 0   1    2t   3le  4lh  5lc  6ls  7un  8St  9   10Qt  11  12Un 13Nw 14CT 15GW 16PB  CS   CS
byte Ready[19]    = {0xD5,0x55,0x00,0x07,0x07,0x07,0x07,0x00,0x38,0x00,0x38,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x01};
byte erroAgua[19] = {0xD5,0x55,0x00,0x00,0x00,0x00,0x00,0x00,0x38,0x00,0x38,0x00,0x38,0x38,0x38,0x00,0x00,0x00,0x01};

//commands              0      1     2     3     4     5     6     7     8    9     10    11    12    13    14    15    16    17    18 
byte powerOnNovo[] =  {0xD5, 0x55, 0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x06, 0x26};
byte powerOn[] =      {0xd5, 0x55, 0x01, 0x01, 0x00, 0x00, 0x02, 0x00, 0x00, 0x00, 0x35, 0x05};
byte requestInfo[] =  {0xD5, 0x55, 0x00, 0x01, 0x00, 0x00, 0x02, 0x00, 0x00, 0x00, 0x01, 0x14}; //nok
byte powerOff[] =     {0xd5, 0x55, 0x00, 0x01, 0x00, 0x00, 0x02, 0x01, 0x00, 0x00, 0x0d, 0x19};
byte hotWater[] =     {0xD5, 0x55, 0x00, 0x01, 0x00, 0x00, 0x02, 0x04, 0x00, 0x00, 0x31, 0x23};
byte espresso[] =     {0xD5, 0x55, 0x00, 0x01, 0x00, 0x00, 0x02, 0x02, 0x00, 0x00, 0x19, 0x0F};
byte coffee[] =       {0xD5, 0x55, 0x00, 0x01, 0x00, 0x00, 0x02, 0x08, 0x00, 0x00, 0x29, 0x3E};
byte steam[] =        {0xD5, 0x55, 0x00, 0x01, 0x00, 0x00, 0x02, 0x10, 0x00, 0x00, 0x19, 0x04};
byte coffeePulver[] = {0xD5, 0x55, 0x00, 0x01, 0x00, 0x00, 0x02, 0x00, 0x02, 0x00, 0x19, 0x0D};
byte coffeeWater[] =  {0xD5, 0x55, 0x00, 0x01, 0x00, 0x00, 0x02, 0x00, 0x04, 0x00, 0x30, 0x27}; 
byte calcNclean[]=    {0xD5, 0x55, 0x00, 0x01, 0x00, 0x00, 0x02, 0x00, 0x20, 0x00, 0x38, 0x15};
byte aquaClean[] =    {0xD5, 0x55, 0x00, 0x01, 0x00, 0x00, 0x02, 0x00, 0x10, 0x00, 0x1D, 0x14};
byte startPause[] =   {0xD5, 0x55, 0x00, 0x01, 0x00, 0x00, 0x02, 0x00, 0x00, 0x01, 0x09, 0x10};

String serialData = ""; 
bool hasMessage = false;
int messageSize = 0;

// function that executes whenever data is requested by master
// this function is registered as an event, see setup()
void requestEvent() {
  // Serial.println("request");
  if (hasMessage) {   
    for (int idx=0; idx<=messageSize;idx++) {
      Wire.write(byteToSend[idx]);
      #ifdef DEBUG_SFW
        Serial.print("0x");
        Serial.print(byteToSend[idx], HEX);
        byteToSend[idx] = 0xFF;
        Serial.print(" ");
      #endif
    }
      #ifdef DEBUG_SFW
        Serial.println("");
      #endif
    hasMessage = false;
  } else Wire.write(0xFF);
}

// function that executes whenever data is received from display
void receiveEvent(int howMany)
{
  // First byte tell where to send the command
  byte destination = Wire.read(); 
  
  switch (destination)
  {
    case 0: // Case message to CoffeMachine
      #ifdef DEBUG_SFW
        Serial.println("Recebido I2C:");        
      #endif
      while(Wire.available()) // loop through last data
      {         
      #ifdef DEBUG_SFW
          Serial.print("0x");          
          Serial.print(Wire.read(), HEX); 
          Serial.print(" ");
        }
        Serial.println(" ");
      #else
          Serial.write(Wire.read()); // send byte to the MB
        }
      #endif
      break;
    case 1: // Case message to panel
      while(Wire.available()) // loop through last data
      {        
        PanelSerial.write(Wire.read()); // send byte to the Panel
      }
      break;
    case 3: // Case powerOn
      #ifdef DEBUG_SFW
        Serial.println("Panel power cicle.");
      #endif
      while (Wire.available()) Wire.read(); // Clear buffer
      digitalWrite(PANEL_GND_PIN, LOW);
      delay(10);
      digitalWrite(PANEL_GND_PIN, HIGH);
      delay(100);
       for (int i=0; i<sizeof(powerOnNovo);i++){
         PanelSerial.write(powerOnNovo[i]);
      }
      break;
  default:
    #ifdef DEBUG_SFW
      Serial.println("Unknow command.");
    #endif
    break;
  }
}

void passthrough(){
  byte c = 0;
  messageSize = 0;  
  // Passtrough CoffeMachine and Panel
  if (PanelSerial.available()) {
    while (PanelSerial.available() > 0) {      
      Serial.write(PanelSerial.read());
      byteToSend[messageSize] = c; // Prepare to send over I2C
      messageSize++;
      if (messageSize>19) messageSize = 0;
    }   
  }
  if (Serial.available()) {      
    while (Serial.available() > 0) {      
      c = Serial.read();
      #ifdef DEBUG_SFW
            // Read the received data      
        if (c==0x3A){
          // Lê a string da Serial até o caractere de nova linha
          String inputString = Serial.readStringUntil('\n');
          Serial.print("String received: ");
          Serial.println(inputString);   
          char delimitador = ',';
          int pos = 0;
          messageSize = 0;
          while ((pos = inputString.indexOf(delimitador)) != -1) {
            String hexValueStr = inputString.substring(0, pos);
            hexValueStr.trim(); 
            hexValueStr.replace("0x", "");
            // Converte a string para um valor numérico hexadecimal
            int hexValue = (int) strtol(hexValueStr.c_str(), NULL, 16);
            byteToSend[messageSize] = hexValue;
            messageSize++;
            Serial.println(hexValue, HEX);
            inputString.remove(0, pos + 1);
          }
        }
        else if (c == 'w') {
          for (int i=0; i< sizeof(Ready);i++) {
          byteToSend[i] = erroAgua[i];                    
          }
          messageSize = 19;
        }
        else if (c == 'r') {
          for (int i=0; i <sizeof(Ready);i++) {
          byteToSend[i] = Ready[i];          
          }
          messageSize = 19;
        }
      #else
        PanelSerial.write(c); // Send to panel
        byteToSend[messageSize] = c; // Prepare to send over I2C
        messageSize++;
        if (messageSize>19) messageSize = 0;
      #endif
    hasMessage = true;
    }  
  }
}

void setup()
{
  pinMode(PANEL_GND_PIN, OUTPUT);
  digitalWrite(PANEL_GND_PIN, HIGH);
  Wire.begin(I2C_ADDRESS);                // join i2c bus with address #4
  Wire.onReceive(receiveEvent); // register event
  Wire.onRequest(requestEvent);
  Serial.begin(115200);         // start serial to talk to the Main Board
  PanelSerial.begin(115200);    // start serial to talk to the Panel
  #ifdef DEBUG_SFW
    Serial.println("Coffee Machine Passtrough Starting...");
    Serial.println("Enter commands to control the coffee machine:");
    Serial.println("'r' - Send ready state to display");
    Serial.println("'w' - Send water error to display");
    Serial.println("':' folowed from 0xXX,... data - Send that message to display");
  #endif
}


void loop()
{
  passthrough();
  delay(10); // to check if its a good value
}
